package com.santosh.anzwholesaleengineering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnzwholesaleengineeringApplication {

    public static void main(String[] args) {
        SpringApplication.run(AnzwholesaleengineeringApplication.class, args);
    }

}
