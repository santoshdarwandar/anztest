package com.santosh.anzwholesaleengineering.controller;

import com.santosh.anzwholesaleengineering.model.Account;
import com.santosh.anzwholesaleengineering.model.AccountTransaction;
import com.santosh.anzwholesaleengineering.service.AccountService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.hateoas.CollectionModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Slf4j
@RestController
@AllArgsConstructor
public class AccountController {

    private AccountService accountService;

    @GetMapping("/accounts")
    private CollectionModel<Account> getAllAccounts() {
        log.info("Getting all accounts");
         List<Account> accounts = accountService.getAllAccounts();
         accounts.forEach(account -> {
             account.add(linkTo(methodOn(AccountController.class).getAllTransactionsForAccount(account.getAccountNumber())).withSelfRel());
         });
        CollectionModel<Account> collectionModel = CollectionModel.of(accounts);
        return collectionModel;
    }

    @GetMapping("/transactions/{accountNumber}")
    private CollectionModel<AccountTransaction> getAllTransactionsForAccount(@PathVariable long accountNumber) {
        log.info("Getting all transactions for account number={}", accountNumber);
        List<AccountTransaction> transactions = accountService.getAllTransactionsForAnAccount(accountNumber);
        CollectionModel<AccountTransaction> collectionModel = CollectionModel.of(transactions);
        collectionModel.add(linkTo(methodOn(AccountController.class).getAllAccounts()).withSelfRel());
        return collectionModel;
    }
}
