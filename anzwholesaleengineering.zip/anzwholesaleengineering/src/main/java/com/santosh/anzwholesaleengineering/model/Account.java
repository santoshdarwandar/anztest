package com.santosh.anzwholesaleengineering.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.springframework.hateoas.RepresentationModel;

import java.util.List;

@Data
@Entity
@Table(name = "TBL_ACCOUNTS")
public class Account extends RepresentationModel<Account> {
    @Id
    private long accountNumber;
    private String accountName;
    private String accountType;
    private String balanceDate;
    private String currency;
    private double openingAvailableBalance;

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<AccountTransaction> accountTransactionList;
}
