package com.santosh.anzwholesaleengineering.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import org.springframework.hateoas.RepresentationModel;

@Data
@Entity
@Table(name = "TBL_ACCOUNT_TRANSACTIONS")
public class AccountTransaction extends RepresentationModel<AccountTransaction> {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonIgnore
    private int transactionId;
    @Transient
    private long accountNumber;
    private String accountName;
    private String valueDate;
    private String currency;
    private Double debitAmount;
    private Double creditAmount;
    private String debitOrCredit;
    private String transactionNarrative;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "account_number")
    private Account account;
}
