package com.santosh.anzwholesaleengineering.model;

public enum AccountType {
    Savings,
    current;
}
