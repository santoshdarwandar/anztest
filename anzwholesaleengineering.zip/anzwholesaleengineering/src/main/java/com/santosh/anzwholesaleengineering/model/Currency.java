package com.santosh.anzwholesaleengineering.model;

public enum Currency {
    SGD,
    AUD;
}
