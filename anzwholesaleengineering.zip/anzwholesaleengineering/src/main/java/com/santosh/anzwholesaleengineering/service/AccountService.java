package com.santosh.anzwholesaleengineering.service;

import com.santosh.anzwholesaleengineering.model.Account;
import com.santosh.anzwholesaleengineering.model.AccountTransaction;
import com.santosh.anzwholesaleengineering.repository.AccountRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@AllArgsConstructor
public class AccountService {
    private  AccountRepository accountRepository;

    public List<Account> getAllAccounts () {
        log.info("Get all accounts");
        List<Account> accounts = new ArrayList();
        accountRepository.findAll().forEach(account -> accounts.add(account));
        return accounts;
    }
    public List<AccountTransaction> getAllTransactionsForAnAccount (final long accountNumber) {
        log.info("Get all transactions for account = {}", accountNumber);
        List<AccountTransaction> transactions = new ArrayList();
        accountRepository.findById(accountNumber).get()
                .getAccountTransactionList().forEach(transaction -> {
                    transaction.setAccountNumber(accountNumber);
                    transactions.add(transaction);
                });
        return transactions;
    }
}
