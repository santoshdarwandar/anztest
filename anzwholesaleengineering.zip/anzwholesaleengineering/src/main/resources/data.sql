INSERT INTO TBL_ACCOUNTS (account_number, account_name, account_type, balance_date, currency, opening_available_balance) VALUES
 (585309209, 'SGSavings726', 'Savings', '08/11/2018', 'SGD', 84327.51),
 (791066619, 'AuSavings933', 'Savings', '08/11/2018', 'AUD', 88005.93);

INSERT INTO TBL_ACCOUNT_TRANSACTIONS (transaction_id, account_number, account_name, value_date, currency, debit_amount, credit_amount, debit_or_credit, transaction_narrative) VALUES
 (1, 585309209, 'SGSavings726', 'Jan 12,2012', 'SGD', NULL, 9540.98, 'Credit', NULL),
 (2, 585309209, 'SGSavings726', 'Jan 12,2012', 'SGD', NULL, 7497.82, 'Credit', NULL);

commit;