package com.santosh.anzwholesaleengineering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnzwholesaleengineeringApplicationTests {

    @Test
    void contextLoads() {
    }

}
