package com.santosh.anzwholesaleengineering.service

import com.santosh.anzwholesaleengineering.repository.AccountRepository
import spock.lang.Subject

class AccountServiceTest extends spock.lang.Specification {
    AccountRepository accountRepository = Mock()
    @Subject AccountService accountService = new AccountService(accountRepository)

    def "GetAllAccounts"() {
        given:'database has accounts'
        accountRepository.findAll() >> Mock()

        when:'get all accounts get called'
        var result = accountService.getAllAccounts()

        then:'result is not null'
        result != null
    }

    def "GetAllTransactionsForAnAccount"() {
        given:'account number'
        var accountNumber = '123'

        and: 'database has record for account number 123'
        accountRepository.findAll() >> Mock()

        when:'get all accounts get called'
        var result = accountService.getAllTransactionsForAnAccount(accountNumber)

        then:'result is not null'
        result != null
    }
}
